﻿using System;
using System.Configuration;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Collections.Generic;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Tooling.Connector;
using RexStudios.ADO.ContactInformation.Interfaces;
using RexStudios.ADO.ContactInformation.BusinessLogic;

namespace ContactInformationTest
{
    class ConsoleTracer : ITracingService
    {
        public void Trace(string message)
        {
            Console.WriteLine(message);
        }
        public void Trace(string format, params object[] args)
        {
            Console.WriteLine(format, args);
        }
    }

    public class Program
    {
        static async Task Main(string[] args)
        {
            // Load configuration from App.config
            var crmUrl = ConfigurationManager.AppSettings["CrmUrl"];
            var tenantId = ConfigurationManager.AppSettings["TenantId"];
            var clientId = ConfigurationManager.AppSettings["ClientId"];
            var clientSecret = ConfigurationManager.AppSettings["ClientSecret"];

            // Validate configuration
            if (string.IsNullOrEmpty(crmUrl) || string.IsNullOrEmpty(tenantId) || 
                string.IsNullOrEmpty(clientId) || string.IsNullOrEmpty(clientSecret))
            {
                Console.WriteLine("Error: Missing required configuration values in App.config");
                Console.WriteLine("Please ensure CrmUrl, TenantId, ClientId, and ClientSecret are configured.");
                Console.ReadKey();
                return;
            }

            Console.WriteLine($"CRM URL: {crmUrl}");
            Console.WriteLine($"Tenant ID: {tenantId}");
            Console.WriteLine($"Client ID: {clientId}");
            Console.WriteLine();

            // Only prompt for Integration Entity Id
            Console.WriteLine("Enter Integration Entity Id:");
            var entityIdInput = Console.ReadLine();

            // Try different scopes to find one that works without IE
            Console.WriteLine("Testing different authentication scopes...");
            
            string accessToken = null;
            var scopesToTest = new[]
            {
                "https://dev.azure.com/Rstudios/.default",                    // Azure DevOps
                "499b84ac-1321-427f-aa17-267ca6975798/.default",    // Visual Studio Team Services
                "https://management.azure.com/.default",             // Azure Resource Manager
                "https://graph.microsoft.com/.default"               // Microsoft Graph
            };

            foreach (var scope in scopesToTest)
            {
                try
                {
                    Console.WriteLine($"Trying scope: {scope}");
                    accessToken = await GetAccessTokenDirectAsync(tenantId, clientId, clientSecret, scope);
                    Console.WriteLine($"✓ Success with scope: {scope}");
                    Console.WriteLine($"Access Token: {accessToken?.Substring(0, 20)}...");
                    break;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"✗ Failed with scope {scope}: {ex.Message}");
                }
            }

            if (string.IsNullOrEmpty(accessToken))
            {
                Console.WriteLine("All scopes failed. Exiting...");
                Console.ReadKey();
                return;
            }

            // Connect to CRM
            var crmConnectionString = $"AuthType=ClientSecret;Url={crmUrl};ClientId={clientId};ClientSecret={clientSecret};TenantId={tenantId}";
            var crmConn = new CrmServiceClient(crmConnectionString);
            IOrganizationService orgService = crmConn.OrganizationWebProxyClient ?? (IOrganizationService)crmConn.OrganizationServiceProxy;

            // Retrieve integration record
            var entityId = Guid.Parse(entityIdInput);
            var integrationEntity = orgService.Retrieve("rex_integrationservice", entityId, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));

            // Execute handler
            var tracer = new ConsoleTracer();
            IIntegrationServiceCreate handler = new CreateIntegrationService(tracer);
            handler.Execute(integrationEntity, orgService, accessToken);

            Console.WriteLine("Handler execution completed.");
        }

        private static async Task<string> GetAccessTokenDirectAsync(string tenantId, string clientId, string clientSecret, string scope)
        {
            var tokenEndpoint = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";
            
            using (var httpClient = new HttpClient())
            {
                var formData = new[]
                {
                    new KeyValuePair<string, string>("grant_type", "client_credentials"),
                    new KeyValuePair<string, string>("client_id", clientId),
                    new KeyValuePair<string, string>("client_secret", clientSecret),
                    new KeyValuePair<string, string>("scope", scope)
                };
                
                var requestContent = new FormUrlEncodedContent(formData);
                var response = await httpClient.PostAsync(tokenEndpoint, requestContent);
                var responseContent = await response.Content.ReadAsStringAsync();
                
                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"HTTP {response.StatusCode}: {responseContent}");
                }
                
                var tokenResponse = JsonSerializer.Deserialize<JsonElement>(responseContent);
                return tokenResponse.GetProperty("access_token").GetString();
            }
        }
    }
}
