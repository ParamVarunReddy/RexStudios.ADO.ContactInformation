using System.Runtime.Serialization;

namespace RexStudios.ADO.ContactInformation.Data
{
    /// <summary>
    /// Represents contact attribute data for serialization.
    /// </summary>
    [DataContract]
    public class ContactAttributeData
    {
        /// <summary>
        /// The JSON Patch operation (add, replace, remove).
        /// </summary>
        [DataMember(Name = "op")]
        public string Operation { get; set; }

        /// <summary>
        /// The JSON Patch target field path, e.g. /fields/System.Title.
        /// </summary>
        [DataMember(Name = "path")]
        public string Field { get; set; }
        
        /// <summary>
        /// The value to apply for the patch operation.
        /// </summary>
        [DataMember(Name = "value")]
        public string Value { get; set; }
    }
}
