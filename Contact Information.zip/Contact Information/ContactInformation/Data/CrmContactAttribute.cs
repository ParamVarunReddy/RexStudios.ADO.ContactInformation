using System.Runtime.Serialization;

namespace RexStudios.ADO.ContactInformation.Data
{
    /// <summary>
    /// Represents CRM contact attribute data for serialization.
    /// </summary>
    [DataContract]
    public class CrmContactAttribute
    {
        /// <summary>
        /// The CRM attribute logical name.
        /// </summary>
        [DataMember(Name = "AttributeName")]
        public string AttributeName { get; set; }

        /// <summary>
        /// The attribute's value as string.
        /// </summary>
        [DataMember(Name = "Value")]
        public string Value { get; set; }
    }
}
