﻿using Microsoft.Xrm.Sdk;
using RexStudios.ADO.ContactInformation.Data;
using RexStudios.ADO.ContactInformation.Interfaces;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;

namespace RexStudios.ADO.ContactInformation.BusinessLogic
{
    public class CreateorUpdateContactInformation : ICreateUpdateContactInformation
    {
        private BeverageConfigurationReader beverageConfigurationReader;
        private string mappingToJson;
        public CreateorUpdateContactInformation()
        { 
        }
        /// <summary>
        /// Placeholder for create logic.
        /// </summary>
        public void Execute(Entity contactEntity, IOrganizationService service)
        {
            beverageConfigurationReader = new BeverageConfigurationReader();
            if (contactEntity == null || service == null)
            {
                Trace.TraceWarning("CreateorUpdateContactInformation.Execute: contactEntity or service is null");
                return;
            }

            // Serialize and map
            string jsonResult = SerializeAttributesToJson(contactEntity);
            // Determine if updating existing ADO work item
            string adoUniqueNumber = contactEntity.Contains("rex_adouniquenumber") ? contactEntity.GetAttributeValue<string>("rex_adouniquenumber") : null;
            // Map CRM attribute names to ADO field names
            if (!string.IsNullOrEmpty(jsonResult))
            {
                string mappingJson = beverageConfigurationReader.GetValue(service, "ADO_ContactDetail");
                if (string.IsNullOrEmpty(mappingJson))
                {
                    Trace.TraceWarning("Field mapping JSON is empty or not found");
                    return;
                }
                else
                {
                    var mappings = new FieldMappingReader().LoadFromJson(mappingJson);
                    mappingToJson = MapJsonFields(jsonResult, mappings, adoUniqueNumber);
                }
            }
            // Create integration record
            CreateIntegrationRecord(contactEntity, service, mappingToJson);
        }

        /// <summary>
        /// Placeholder for update logic.
        /// </summary>
        public void Update(Entity contactEntity, IOrganizationService service)
        {
            beverageConfigurationReader = new BeverageConfigurationReader();
            if (contactEntity == null || service == null)
            {
                Trace.TraceWarning("CreateorUpdateContactInformation.Update: contactEntity or service is null");
                return;
            }

            // Serialize and map
            string jsonResult = SerializeAttributesToJson(contactEntity);
            // Determine if updating existing ADO work item
            string adoUniqueNumber = contactEntity.Contains("rex_adouniquenumber") ? contactEntity.GetAttributeValue<string>("rex_adouniquenumber") : null;
            // Map CRM attribute names to ADO field names
            if (!string.IsNullOrEmpty(jsonResult))
            {
                string mappingJson = beverageConfigurationReader.GetValue(service, "ADO_ContactDetail");
                if (string.IsNullOrEmpty(mappingJson))
                {
                    Trace.TraceWarning("Field mapping JSON is empty or not found");
                    return;
                }
                else
                {
                    var mappings = new FieldMappingReader().LoadFromJson(mappingJson);
                    mappingToJson = MapJsonFields(jsonResult, mappings, adoUniqueNumber);
                }
            }
            // Create integration record for update
            CreateIntegrationRecord(contactEntity, service, mappingToJson);
        }

        /// <summary>
        /// Common helper to serialize contact attributes to JSON
        /// </summary>
        private string SerializeAttributesToJson(Entity contactEntity)
        {
            if (contactEntity == null || contactEntity.Attributes == null)
            {
                Trace.TraceWarning("CreateorUpdateContactInformation.SerializeAttributesToJson: contactEntity or Attributes is null");
                return string.Empty;
            }
            var attributeDataList = contactEntity.Attributes
                .Where(kvp => kvp.Value != null)
                .Select(kvp => new CrmContactAttribute
                {
                    AttributeName = kvp.Key,
                    Value = kvp.Value is OptionSetValue osVal ? osVal.Value.ToString()
                        : kvp.Value is EntityReference er ? er.Name
                        : kvp.Value.ToString()
                })
                .ToList();
            var serializer = new DataContractJsonSerializer(typeof(List<CrmContactAttribute>));
            using (var ms = new MemoryStream())
            {
                serializer.WriteObject(ms, attributeDataList);
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }
        
        /// <summary>
        /// Creates a rex_integrationservice record for the contact.
        /// </summary>
        private void CreateIntegrationRecord(Entity contactEntity, IOrganizationService service, string jsonString)
        {
            if (contactEntity == null || service == null || string.IsNullOrEmpty(jsonString))
            {
                Trace.TraceWarning("CreateorUpdateContactInformation.CreateIntegrationRecord: invalid parameters");
                return;
            }
            // Title from contact's full name
            string title = contactEntity.Contains("rex_regardingobject") ? contactEntity.GetAttributeValue<EntityReference>("rex_regardingobject").Name : string.Empty;
            // ADO Unique Number
            string adoUniqueNumber = contactEntity.Contains("rex_adouniquenumber") ? contactEntity.GetAttributeValue<string>("rex_adouniquenumber") : string.Empty;
            // Target GUID
            string targetGuid = contactEntity.Contains("rex_adoguid") ? contactEntity.GetAttributeValue<string>("rex_adoguid") : string.Empty;
            // Target Link placeholder
            string targetLink = contactEntity.Contains("rex_adolink") ? contactEntity.GetAttributeValue<string>("rex_adolink") : string.Empty;

            var integrationEntity = new Entity("rex_integrationservice");
            integrationEntity["rex_title"] = title;
            integrationEntity["rex_request"] = jsonString;
            integrationEntity["rex_targetuniquenumber"] = adoUniqueNumber;
            integrationEntity["rex_targetguid"] = targetGuid;
            integrationEntity["rex_targetlink"] = targetLink;
            // Set regarding to contact
            integrationEntity["rex_regardingobject"] = new EntityReference("contact", contactEntity.Id);

            service.Create(integrationEntity);
        }

        /// <summary>
        /// Maps JSON array fields from CRM attribute names to ADO field names based on provided mappings.
        /// Unmapped CRM fields are logged and removed.
        /// </summary>
        // Build a JSON Patch document for create (add) or update (replace)
        private string MapJsonFields(string jsonContent, List<FieldMappingItem> mappings, string adoUniqueNumber)
        {
            if (string.IsNullOrEmpty(jsonContent) || mappings == null)
                return jsonContent;

            try
            {
                // Deserialize to ContactAttributeData list
                var serializer = new DataContractJsonSerializer(typeof(List<CrmContactAttribute>));
                List<CrmContactAttribute> list;
                using (var msRead = new MemoryStream(Encoding.UTF8.GetBytes(jsonContent)))
                {
                    list = (List<CrmContactAttribute>)serializer.ReadObject(msRead);
                }
                // Determine operation type
                string opType = string.IsNullOrEmpty(adoUniqueNumber) ? "add" : "replace";
                // Build patch operations
                var patchOps = new List<ContactAttributeData>();
                foreach (var mapping in mappings)
                {
                    var item = list.FirstOrDefault(a => a.AttributeName.Equals(mapping.CrmFieldName, StringComparison.OrdinalIgnoreCase));
                    if (item == null)
                    {
                        Trace.TraceWarning($"No data for CRM field '{mapping.CrmFieldName}'");
                        continue;
                    }
                    patchOps.Add(new ContactAttributeData
                    {
                        Operation = opType,
                        Field = $"/fields/{mapping.AdoFieldName}",
                        Value = item.Value
                    });
                }
                // Serialize patch document using DataContractJsonSerializer
                var writeSerializer = new DataContractJsonSerializer(typeof(List<ContactAttributeData>));
                using (var msWrite = new MemoryStream())
                {
                    writeSerializer.WriteObject(msWrite, patchOps);
                    return Encoding.UTF8.GetString(msWrite.ToArray());
                }
            }
            catch (Exception ex)
            {
                Trace.TraceError($"MapJsonFields failed: {ex.Message}");
                return jsonContent;
            }
        }
    }
}